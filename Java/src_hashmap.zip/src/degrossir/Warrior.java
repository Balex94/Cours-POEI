package degrossir;

public class Warrior extends Marchand implements ICombattant {
	
	public int life;
	
	public Warrior() {
		super();
		
		this.life = 100;
	}
	
	
	public void attaquer( ICombattant p_opponent ) {
		p_opponent.recevoirDegats(20);
	}
	
	
	public void recevoirDegats( int p_degats ) {
		this.life -= p_degats;
		
		if( this.life < 50 ) {
			LifePotion potion = this.getInventory().getLifePotion();
			
			if( potion != null ) {
				this.life = 100;
				this.getInventory().removeItem(potion);
			}
		}
	}
	
	
}
