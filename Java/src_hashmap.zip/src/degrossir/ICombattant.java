package degrossir;

public interface ICombattant {

	public void attaquer( ICombattant p_opponent );
	public void recevoirDegats( int p_degats );
	
}
