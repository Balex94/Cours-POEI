package degrossir;

public class LifePotion extends Item {
	public LifePotion() {
		super( "Life Potion", 20);
	}
}
