package degrossir;

public class Wizard extends Marchand implements ICombattant {
	
	public int life;
	public int mana;
	
	public Wizard() {
		super();
		
		this.life = 100;
		this.mana = 100;
	}
	
	
	public void attaquer( ICombattant p_opponent ) {
		
		if( this.mana <= 15) {
			ManaPotion potion = this.getInventory().getManaPotion();
			
			if( potion != null ) {
				this.mana = 100;
				this.getInventory().removeItem(potion);
			}
		}
		
		if( this.mana >= 15 )
			p_opponent.recevoirDegats(25);
		
	}
	
	
	public void recevoirDegats( int p_degats ) {
		this.life -= p_degats;
		
		if( this.life < 50 ) {
			LifePotion potion = this.getInventory().getLifePotion();
			
			if( potion != null ) {
				this.life = 100;
				this.getInventory().removeItem(potion);
			}
		}
	}
	
	
}
