package degrossir;

public class Account {
	
	private static int counter = 0;
	
	public String accountId;
	public int gold;
	
	public Account( int p_gold ) {
		
		this.accountId = "account_" + Account.counter;
		Account.counter++;
		
		this.gold = p_gold;
	}
}
