package degrossir;

public class ManaPotion extends Item {
	public ManaPotion() {
		super( "Mana Potion", 20);
	}
}
