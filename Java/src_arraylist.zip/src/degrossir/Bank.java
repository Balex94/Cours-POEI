package degrossir;

import java.util.ArrayList;

public class Bank {
	
	static private Bank toto = null;
	
	static public Bank getInstance() {
		if( Bank.toto == null )
			Bank.toto = new Bank();
		
		return Bank.toto;
	}
	
	private ArrayList<Account> accounts;
	
	private Bank() {
		this.accounts = new ArrayList<Account>();
	}
	
	public Account getAccountById( String p_id ) {
		
		for( int i = 0; i < this.accounts.size(); i++ ) {
			if( this.accounts.get(i).accountId == p_id)
				return this.accounts.get(i);
		}
		
		return null;
	}
	
	public boolean addGold( String p_id, int p_gold ) {
		Account current = this.getAccountById(p_id);
		
		if( current != null && current.gold + p_gold > 0 ) {
			current.gold += p_gold;
			return true;
		}
		else {
			return false;
		}
	}
	
	public int grabGold( String p_id, int p_gold ) {
		Account current = this.getAccountById(p_id);
		
		if( current != null && current.gold - p_gold >= 0 ) {
			current.gold -= p_gold;
			return p_gold;
		}
		else {
			int value = current.gold;
			current.gold = 0;
			return value;
		}
	}
	
	public String openAccount(int p_value) {
		Account current = new Account(p_value);
		this.accounts.add( current );
		return current.accountId;
	}
	
	public void removeAccount( String p_id ) {
		Account current = this.getAccountById(p_id);
		
		if( current != null )
			this.accounts.remove(current);
	}

}
