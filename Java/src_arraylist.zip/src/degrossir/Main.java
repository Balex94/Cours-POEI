package degrossir;

import java.util.ArrayList;

import degrossir.*;

public class Main {

	public static void main(String[] args) {
		
		
		Marchand venec 	= new Marchand();
		Warrior regis 	= new Warrior();
		Wizard nam 		= new Wizard();
		
		venec.accountId = Bank.getInstance().openAccount(1000);
		regis.accountId = Bank.getInstance().openAccount(200);
		nam.accountId 	= Bank.getInstance().openAccount(200);
		
		ManaPotion potA = null;
		LifePotion potB = null;
		
		regis.setGold( Bank.getInstance().grabGold(regis.accountId, 8000 ));
		
		System.out.println(regis.getGold());
		System.out.println(Bank.getInstance().getAccountById(regis.accountId).gold);
		/*
		int i = 100;
		
		while( --i > -1 ) {
			venec.getInventory().addItem( new LifePotion() 	);
			venec.getInventory().addItem( new ManaPotion() 	);
		}

		// tant que Regis poss�de de l'or en quantit� suffisante 
		// et que le marchand poss�de des potions de vie � vendre ...
		potB = venec.getInventory().getLifePotion();
		
		while( potB != null && regis.getGold() >= potB.price ) {
			
			// Regis ach�te des potions de vie.
			venec.vendre(potB);
			regis.acheter(potB);
			
			potB = venec.getInventory().getLifePotion();
		}
		

		// tant que Nam poss�de de l'or en quantit� suffisante...
		
		potA = venec.getInventory().getManaPotion();
		potB = venec.getInventory().getLifePotion();				
		
		while( 
				potA != null && 
				potB != null && 
				nam.getGold() >= (potA.price + potB.price) 
		) {
		
			venec.vendre(potB);
			nam.acheter(potB);
		
		
			venec.vendre(potA);
			nam.acheter(potA);
			
			potA = venec.getInventory().getManaPotion();
			potB = venec.getInventory().getLifePotion();				
		}
		
		
		/*
		while( regis.life > 0 && nam.life > 0 ) {
			nam.attaquer(regis);
			regis.attaquer(nam);
		}
		
		if( regis.life == 0 ) {
			System.out.println("Nam a remport� le combat !");
		}else {
			System.out.println("R�gis a forc�ment trich�");
		}
		*/
	}
	
}
