package degrossir;

public class Item implements Comparable<Item>{

	public int price;
	public String name;
	
	public Item( String p_name, int p_price) {
		this.name = p_name;
		this.price = p_price;
	}
	
	public int compareTo(Item item){
		if( this.price > item.price ) {
			return 1;
		}else {
			return -1;
		}
	}

}
