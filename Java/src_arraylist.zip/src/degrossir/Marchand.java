package degrossir;

import java.util.ArrayList;

public class Marchand {

	public String accountId;
	private int or;
	private Inventory inventaire;
	
	public Marchand() {
		this.accountId 	= null;
		this.or 		= 0;
		this.inventaire = new Inventory();
	}
	
	public void setGold(int p_value) {
		this.or = p_value;
	}
	
	public int getGold() {
		return this.or;
	}
	
	public Inventory getInventory() {
		return this.inventaire;
	}
	
	public void vendre( Item p_item ) {
		this.or += p_item.price;
		this.inventaire.removeItem(p_item);
	}
	
	public void acheter(Item p_item) {
		this.or -= p_item.price;
		this.inventaire.addItem(p_item);
	}
	

}
