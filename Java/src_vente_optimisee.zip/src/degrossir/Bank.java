package degrossir;

import java.util.HashMap;

public class Bank {
	
	static private HashMap<String, Bank> dict = new HashMap<String, Bank>();
	
	static public Bank getInstance( String p_key) {
		if( Bank.dict.containsKey(p_key) == false )
			Bank.dict.put(p_key, new Bank());
		
		return Bank.dict.get(p_key);
	}
	
	private HashMap<String, Account> accounts;
	
	private Bank() {
		this.accounts = new HashMap<String, Account>();
	}
	
	public Account getAccountById( String p_id ) {
		
		if( this.accounts.containsKey(p_id))
			return this.accounts.get(p_id);
		else
			return null;
	}
	
	public boolean addGold( String p_id, int p_gold ) {
		Account current = this.getAccountById(p_id);
		
		if( current != null )
			return false;
		
		if( current.gold + p_gold > 0 ) {
			current.gold += p_gold;
			return true;
		}
		else {
			return false;
		}
	}
	
	public int grabGold( String p_id, int p_gold ) {
		Account current = this.getAccountById(p_id);
		
		if( current == null )
			return 0;
		
		if( current.gold - p_gold >= 0 ) {
			current.gold -= p_gold;
			return p_gold;
		}
		else {
			int value = current.gold;
			current.gold = 0;
			return value;
		}
	}
	
	public String openAccount(int p_value) {
		Account current = new Account(p_value);
		this.accounts.put( current.accountId, current );
		return current.accountId;
	}
	
	public void removeAccount( String p_id ) {
		
		if (this.accounts.containsKey(p_id) )
			this.accounts.remove(p_id);
	}

}
