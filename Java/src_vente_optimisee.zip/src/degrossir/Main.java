package degrossir;

import java.util.ArrayList;

import degrossir.*;

public class Main {

	public static void main(String[] args) {
		
		
		Marchand venec 	= new Marchand();
		Warrior regis 	= new Warrior();
		Wizard nam 		= new Wizard();
		
		venec.accountId = Bank.getInstance("bnp").openAccount(1000);
		regis.accountId = Bank.getInstance("bnp").openAccount(200);
		nam.accountId 	= Bank.getInstance("bnp").openAccount(200);
		
		
		regis.setGold( Bank.getInstance("bnp").grabGold(regis.accountId, 8000 ));
		
		System.out.println(regis.getGold());
		System.out.println(Bank.getInstance("bnp").getAccountById(regis.accountId).gold);
		
		int i = 100;
		
		while( --i > -1 ) {
			venec.getInventory().addItem( new LifePotion() 	);
			venec.getInventory().addItem( new ManaPotion() 	);
		}

		// tant que le marchand poss�de des potions de vie � vendre ...
		// et que la vente r�ussit
		
		while( venec.vendre(regis, venec.getInventory().getLifePotion() ) ) {}

		
		// tant qu'il y a des potions � vendre et qu'on r�ussit � les vendre ...
		while( 	
				venec.vendre(nam, venec.getInventory().getLifePotion() ) && 
				venec.vendre(nam, venec.getInventory().getManaPotion() ) 
		) {}
		
		
		while( regis.life > 0 && nam.life > 0 ) {
			nam.attaquer(regis);
			regis.attaquer(nam);
		}
		
		if( regis.life == 0 ) {
			System.out.println("Nam a remport� le combat !");
		}else {
			System.out.println("R�gis a forc�ment trich�");
		}
		
	}
	
}
