package degrossir;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;

public class Inventory {

	private ArrayList<Item> items;
	private int limit;
	
	public Inventory() {
		
		this.limit = 200;
		this.items = new ArrayList<Item>();
		
	}
	
	public LifePotion getLifePotion() {
		
		int i = 0;
		int max = 0;
		
		ArrayList<Item> tab = this.items;
		max = tab.size();
		
		for( i = 0; i < max; i++ ) {
			if( tab.get(i) instanceof LifePotion ) {
				
				LifePotion potion = (LifePotion)(tab.get(i));
				return potion;
			}
		}
		
		return null;
	}

	public ManaPotion getManaPotion() {
		
		int i = 0;
		int max = 0;
		
		ArrayList<Item> tab = this.items;
		max = tab.size();
		
		for( i = 0; i < max; i++ ) {
			if( tab.get(i) instanceof ManaPotion ) {
				
				ManaPotion potion = (ManaPotion)(tab.get(i));
				return potion;
			}
		}
		
		return null;
	}
	
	
	
	public void sortByPrice() {
		
		Comparator<Item> compA = new Comparator<Item>() {
			
			public int compare( Item a , Item b) {
				if( a.price > b.price ) {
					return 1;
				}
				else if( a.price == b.price ) {
					return 0;
				}
				else {
					return -1;
				}
			}
		
		};
		
		
		Comparator<Item> compB = new Comparator<Item>() {
			
			public int compare( Item a , Item b) {
				if( a.price < b.price ) {
					return 1;
				}
				else if( a.price == b.price ) {
					return 0;
				}
				else {
					return -1;
				}
			}
		
		};
		
		
		this.items.sort( compB );
		
		
		
		//Collections.sort(this.items);
		
	}
	
	public ArrayList<Item> getItems(){
		return this.items;
	}
	
	public boolean addItem( Item p_item ) {
		
		if( this.items.size() < this.limit ) 
		{
			this.items.add(p_item);
			return true;
		}
		else 
		{
			return false;
		}
		
	}
	
	public boolean removeItem(Item p_item) {
		return this.items.remove(p_item);
	}
	
	public boolean replaceItem( Item p_search, Item p_replace ) {
		if( this.items.contains(p_search) == false )
			return false;
		
		int index = this.items.indexOf(p_search);
		this.items.set(index, p_replace);
		return true;
	}

}
