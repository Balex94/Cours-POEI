package degrossir;

import java.util.ArrayList;

public class Marchand {

	public String accountId;
	private int or;
	private Inventory inventaire;
	
	public Marchand() {
		this.accountId 	= null;
		this.or 		= 0;
		this.inventaire = new Inventory();
	}
	
	public void setGold(int p_value) {
		this.or = p_value;
	}
	
	public int getGold() {
		return this.or;
	}
	
	public Inventory getInventory() {
		return this.inventaire;
	}
	
	public boolean vendre( Marchand p_buyer, Item p_item ) {
		
		if( p_item == null )
			return false;
		
		int buyerGold = p_buyer.getGold();
		
		if( buyerGold >= p_item.price ) {
			this.or += p_item.price;
			p_buyer.setGold( buyerGold - p_item.price );
			this.inventaire.removeItem(p_item);
			p_buyer.inventaire.addItem(p_item);
			
			return true;
		}
		else {
			return false;
		}
	}
	

}
